class CommitValidationException(Exception):
    def __init__(self, exception_message: str = "Failed to validate the git commit."):
        self.exception_message = exception_message

        super().__init__(self.exception_message)