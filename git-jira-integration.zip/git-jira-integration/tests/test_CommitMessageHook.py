import io
import os
from contextlib import redirect_stderr
from unittest import TestCase
from unittest.mock import patch
import CommitMessageHook
from CommitValidationException import CommitValidationException
from DictionaryValidationException import DictionaryValidationException


class TestCommitMessageHook(TestCase):

    def test_valid_id_extraction(self):
        # Given
        commit_message = ["TicketID: RandomTicketID", "Commit Line 2", "Commit Line 3"]

        # When
        result = CommitMessageHook.extract_ticket_id(commit_message)

        # Then
        self.assertEqual(result, "RandomTicketID")

    def test_invalid_id_extraction(self):
        # Given
        commit_message = ["Commit Line 1", "Commit Line 2", "Commit Line 3"]

        # When
        result = CommitMessageHook.extract_ticket_id(commit_message)

        # Then
        self.assertEqual(result, None)

    @patch('CommitMessageHook.extract_ticket_id')
    @patch('Util.read_simple_file')
    def test_correct_output_on_missing_id(self, mock_read_simple_file, mock_extract_ticket_id):
        # Given
        mock_read_simple_file.return_value = []
        mock_extract_ticket_id.return_value = None

        # When & Then
        with self.assertRaises((CommitValidationException, RuntimeError)) as context:
            CommitMessageHook.process_commit_message("RandomFilePath", "User_Email")
        self.assertEqual("Error while processing the commit: A valid ticketID was not present in commit message.\nPlease use the following format:"
                         "\"TicketID: XXXXXX\" to delimit your ticket ID! (X's are to be replaced by the actual ID)", str(context.exception))

    def test_correct_output_on_missing_file(self):
        # Given
        file_path = "RandomFilePath"

        # When & Then
        with self.assertRaises(RuntimeError) as context:
            CommitMessageHook.process_commit_message(file_path, "User_Email")
        self.assertEqual("Error while processing the commit: Could not find file at \"RandomFilePath\".", str(context.exception))

    @patch('CommitMessageHook.JiraService')
    @patch('CommitMessageHook.hook_config', {'commit-msg': {'valid_commit_status': ['In Progress']}})
    def test_output_on_invalid_ticket_status(self, mock_jira_service):
        # Given
        mock_jira_service().get_issue.return_value = {'status': 'RandomStatus', 'assignee':
            {'email': 'User_Email', 'user_id': 'User_Name'}, 'issue_id': 'TEST-123'}
        mock_jira_service().get_possible_transitions.return_value = ['Test1', 'Test2']

        # When & Then
        with self.assertRaises(CommitValidationException) as context:
            CommitMessageHook.check_commit_validity("TEST-123", "User_Email")
        self.assertEqual("The ticket \"TEST-123\" is in a not commitable status (RandomStatus).", str(context.exception))

    @patch('CommitMessageHook.JiraService')
    @patch('CommitMessageHook.hook_config', {'commit-msg': {'valid_commit_status': ['In Progress'], 'validate_assignee': True,
                                             'warning_on_invalid_assignee': False}})
    def test_output_on_assignee_mismatch(self, mock_jira_service):
        # Given
        mock_jira_service().get_issue.return_value = {'status': 'In Progress', 'assignee':
            {'email': 'User_Email', 'user_id': 'User_Name'}, 'issue_id': 'TEST-123'}
        mock_jira_service().get_possible_transitions.return_value = ['Test1', 'Test2']

        # When & Then
        with self.assertRaises(CommitValidationException) as context:
            CommitMessageHook.check_commit_validity("TEST-123", "Random_Email")
        self.assertEqual("Ticket \"TEST-123\" is not assigned to you.", str(context.exception))

    @patch('CommitMessageHook.JiraService')
    @patch('CommitMessageHook.hook_config', {'commit-msg': {'valid_commit_status': ['In Progress'], 'validate_assignee': True,
                                             'warning_on_invalid_assignee': True}})
    @patch('CommitMessageHook.messagebox.askokcancel', return_value=False)
    def test_output_on_assignee_mismatch_with_warning(self, mock_askokcancel, mock_jira_service,):
        # Given

        mock_jira_service().get_issue.return_value = {'status': 'In Progress', 'assignee':
            {'email': 'User_Email', 'user_id': 'User_Name'}, 'issue_id': 'TEST-123'}
        mock_jira_service().get_possible_transitions.return_value = ['Test1', 'Test2']

        # When & Then
        with self.assertRaises(CommitValidationException) as context:
            CommitMessageHook.check_commit_validity("TEST-123", "Random_Email")
        self.assertEqual("Commit aborted by user, ticket \"TEST-123\" is not assigned to user.", str(context.exception))

    @patch('CommitMessageHook.JiraService')
    @patch('CommitMessageHook.hook_config', {'commit-msg': {'valid_commit_status': ['In Progress'], 'validate_assignee': False,
                                             'warning_on_invalid_assignee': True}})
    def test_successful_commit_validation(self, mock_jira_service):
        # Given
        mock_jira_service().get_issue.return_value = {'status': 'In Progress', 'assignee':
            {'email': 'User_Email', 'user_id': 'User_Name'}, 'issue_id': 'TEST-123'}
        mock_jira_service().get_possible_transitions.return_value = ['Test1', 'Test2']
        expected_result = {'issue': {'issue_id': 'TEST-123', 'status': 'In Progress', 'assignee': {'email': 'User_Email', 'user_id': 'User_Name'}}, 'transitions': ['Test1', 'Test2']}

        # When
        result = CommitMessageHook.check_commit_validity("TEST-123", "User_Email")

        # Then
        self.assertDictEqual(result, expected_result)

    @patch('CommitMessageHook.load_metadata_file', return_value={})
    @patch('Util.write_json_file')
    @patch('Util.read_simple_file', return_value=['ExampleRelativePath'])
    def test_successful_update_metadata(self, mock_load_metadata_file, mock_write_metadata_file, mock_read_simple_file):
        # Given
        base_url = "https://test.jira.com/"
        ticket_id = "TEST-123"
        ticket_status = "In Progress"
        ticket_assignee = "User 1"
        expected_result = {'ExampleRelativePath': {'jira_properties': {'ticket_status': 'In Progress', 'assignee': 'User 1',
                                                                'ticket_id': 'TEST-123',
                                                                'ticket_url': 'https://test.jira.com/browse/TEST-123'},
                                            'km_properties': {}}}

        # When
        CommitMessageHook.update_metadata_file("Test", "Test", ticket_id, ticket_status,
                                               ticket_assignee, base_url)

        self.assertDictEqual(mock_write_metadata_file.call_args[0][1], expected_result)

    @patch('CommitMessageHook.load_metadata_file', return_value={})
    @patch('Util.write_json_file')
    @patch('Util.read_simple_file', return_value=['.gitignore'])
    def test_gitignore_skip(self, mock_load_metadata_file, mock_write_metadata_file, mock_read_simple_file):
        # Given
        base_url = "https://test.jira.com/"
        ticket_id = "TEST-123"
        ticket_status = "In Progress"
        ticket_assignee = "User 1"
        expected_result = {}

        # When
        CommitMessageHook.update_metadata_file("Test", "Test", ticket_id, ticket_status,
                                               ticket_assignee, base_url)

        # Then
        self.assertDictEqual(mock_write_metadata_file.call_args[0][1], expected_result)

    @patch('CommitMessageHook.load_metadata_file', return_value={'ExampleRelativePath2':
                                                                     {'jira_properties': {'ticket_status': 'Backlog',
                                                                                          'assignee': 'User 2',
                                                                                          'ticket_url': 'https://test.jira.com/browse/TEST-123'},
                                                                      'km_properties': {}}})
    @patch('Util.write_json_file')
    @patch('Util.read_simple_file', return_value=['ExampleRelativePath'])
    def test_malformed_jira_props(self, mock_load_metadata_file, mock_write_metadata_file, mock_read_simple_file):
        # Given
        base_url = "https://test.jira.com/"
        ticket_id = "TEST-123"
        ticket_status = "In Progress"
        ticket_assignee = "User 1"

        # When & Then
        with self.assertRaises((KeyError, RuntimeError)) as context:
            CommitMessageHook.update_metadata_file("Test", "Test", ticket_id, ticket_status,
                                               ticket_assignee, base_url)
        self.assertEqual("Error while updating the metadata file: 'Failed to update \"ExampleRelativePath2\" in the"
                         " metadata file, the element does not contain the necessary jira properties.'", str(context.exception))


    @patch('os.path.isfile', return_value=True)
    @patch('Util.read_json_file', return_value={'TestMetadata': 'Value'})
    def test_successful_load_metadata(self, mock_read_json_file, mock_isfile):
        # Given
        expected_result = {'TestMetadata': 'Value'}

        # When
        result = CommitMessageHook.load_metadata_file("Test")

        # Then
        self.assertDictEqual(result, expected_result)

    @patch('os.path.isfile', return_value=False)
    @patch('CommitMessageHook.messagebox.askokcancel', return_value=False)
    def test_missing_metadata_file(self, mock_isfile, mock_askokcancel):
        # Given

        # When & Then
        with self.assertRaises(IOError) as context:
            CommitMessageHook.load_metadata_file("Test")
        self.assertEqual("Could not find metadata file at: \"Test\".", str(context.exception))

    @patch('Util.validate_dict', side_effect=KeyError("Malformed Dictionary."))
    def test_malformed_config_output(self, mock_validate_dict):
        # Given
        config_json = {'jira_cred_filepath': 'Test',
                       'commit-msg': {'valid_commit_status': ['In Progress'], 'validate_assignee': True,
                                      'warning_on_invalid_assignee': False}}
        # When & Then
        with self.assertRaises(DictionaryValidationException) as context:
            CommitMessageHook._validate_configurations(config_json)
        self.assertEqual("Failed to validate the configuration file!\n'Malformed Dictionary.'", str(context.exception))

    @patch('Util.validate_dict', return_value=None)
    def test_successful_config_validation(self, mock_validate_dict):
        # Given
        config_json = {'jira_cred_filepath': 'Test', 'metadata_filepath': 'Test',
                       'commit-msg': {'valid_commit_status': ['In Progress'], 'validate_assignee': True,
                                      'warning_on_invalid_assignee': False}}

        # When
        try:
            CommitMessageHook._validate_configurations(config_json)
        except DictionaryValidationException:
            self.fail("DictionaryValidationException raised unexpectedly!")


    @patch('Util.read_json_file', return_value={})
    @patch('CommitMessageHook._validate_configurations', side_effect=DictionaryValidationException("Failed to validate the configuration file!\n'Malformed Dictionary.'"))
    def test_invalid_load_configurations(self, mock_validate_config, mock_read_json_file):
        # Given
        config_file = "Test"

        # When & Then
        with self.assertRaises(RuntimeError) as context:
            CommitMessageHook.load_configurations(config_file)
        self.assertEqual("Error while loading the script configuration: Failed to validate the configuration file!\n'Malformed Dictionary.'", str(context.exception))

    @patch('Util.read_json_file', return_value={'jira_cred_filepath': 'Test'})
    @patch('CommitMessageHook._validate_configurations', return_value=None)
    @patch('Util.load_jira_credentials', return_value={})
    def test_successful_load_configurations(self, mock_validate_config, mock_read_json_file, mock_load_jira_credentials):
        # Given
        config_file = "Test"

        # When & Then
        try:
            CommitMessageHook.load_configurations(config_file)
        except RuntimeError:
            self.fail("RuntimeError raised unexpectedly!")

    @patch('Util.read_json_file', return_value={})
    @patch('Util.write_json_file')
    def test_successful_transition_update(self, mock_write_json_file, mock_read_json_file):
        # Given
        test_id = "TEST-123"
        test_transition = {'id': 1, 'status': 'TestStatus'}
        expected_result = {'TEST-123': {'id': 1, 'status': 'TestStatus'}}

        # When
        CommitMessageHook.append_push_transition_to_file(test_id, test_transition)

        # Then
        self.assertDictEqual(mock_write_json_file.call_args[0][1], expected_result)

    @patch('Util.read_json_file', return_value={'TEST-123': {'id': 1, 'status': 'TestStatus'}})
    @patch('Util.write_json_file')
    def test_transition_update_existing(self, mock_write_json_file, mock_read_json_file):
        # Given
        test_id = "TEST-123"
        test_transition = {'id': 2, 'status': 'TestStatus2'}
        expected_result = {'TEST-123': {'id': 2, 'status': 'TestStatus2'}}

        # When
        CommitMessageHook.append_push_transition_to_file(test_id, test_transition)

        # Then
        self.assertDictEqual(mock_write_json_file.call_args[0][1], expected_result)

    @patch('Util.read_json_file', return_value={'TEST-123': {'id': 1, 'status': 'TestStatus'}})
    @patch('Util.write_json_file')
    def test_transition_remove_on_revert(self, mock_write_json_file, mock_read_json_file):
        # Given
        test_id = "TEST-123"
        test_transition = {'id': None, 'status': 'TestStatus2'}
        expected_result = {}

        # When
        CommitMessageHook.append_push_transition_to_file(test_id, test_transition)

        # Then
        self.assertDictEqual(mock_write_json_file.call_args[0][1], expected_result)

    @patch('Util.read_json_file', return_value={})
    @patch('Util.write_json_file', side_effect=IOError("Could not write to file at \"Test\", permission denied."))
    def test_unsuccessful_transition_update(self, mock_write_json_file, mock_read_json_file):
        # Given
        test_id = "TEST-123"
        test_transition = {'id': 1, 'status': 'TestStatus'}

        # When & Then
        with self.assertRaises(RuntimeError) as context:
            CommitMessageHook.append_push_transition_to_file(test_id, test_transition)
        self.assertEqual("Error while updating the status transition file: Could not write to file at \"Test\", permission denied.", str(context.exception))

    @patch('Util.check_for_system_commit', return_value=False)
    @patch('sys.argv', ['Test', 'Test'])
    def test_invalid_amount_of_arguments(self, mock_check_for_system_commit):
        # Given
        buffer = io.StringIO()
        # When & Then
        with redirect_stderr(buffer):
            CommitMessageHook.main()
        self.assertEqual("Script was invoked with an invalid amount of arguments!", buffer.getvalue())

    @patch('Util.check_for_system_commit', return_value=True)
    @patch('Util.check_system_commit_file_empty', return_value=False)
    def test_output_on_non_empty_sys_commit(self, mock_check_system_commit_file_empty, mock_check_for_system_commit):
        # Given
        buffer = io.StringIO()
        current_directory = os.getcwd().replace("\\", "/") + "/"
        # When & Then
        with redirect_stderr(buffer):
            CommitMessageHook.main()
        self.assertEqual(f"System commit file is not empty, post commit hook failed.\nPlease check your commit"
                                 f" history, and if necessary, revert the last commit.\nFurthermore remove the following file:"
                                 f" \"{current_directory}.git/.system_commit\".", buffer.getvalue())