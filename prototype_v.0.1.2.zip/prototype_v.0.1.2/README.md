### Requirements

- Python 3.10+
- Atlassian Python API Module (Install with `pip install atlassian-python-api`)

### Installation Guide
1. Clone a repository of your choice
---

2. Add the `python_hook_files` folder to your repository

![add_hooks.png](md_files%2Fadd_hooks.png)

---

3. Navigate to the `.git/hooks` folder in your repository

![nav_hooks_folder.png](md_files%2Fnav_hooks_folder.png)

---

4. Copy the contents of the `shell_hook_files` folder into the `.git/hooks` folder

![shell_hooks.png](md_files%2Fshell_hooks.png)

---

5. Navigate to the `.git` folder in your repository and add the contents of the `configuration_files` folder to the `.git` folder

![config_files.png](md_files%2Fconfig_files.png)

---
6. Open the `jira_cred.json` file in the `.git` folder and fill in the required fields

(You can generate an API token by following this [link](https://devstack.vwgroup.com/jira/plugins/servlet/de.resolution.apitokenauth/admin))

![jira_creds.png](md_files%2Fjira_creds.png)


---

7. (Optional) Edit the `hook_config.json` file in the `.git` folder to change the default settings


![hook_config.png](md_files%2Fhook_config.png)

---