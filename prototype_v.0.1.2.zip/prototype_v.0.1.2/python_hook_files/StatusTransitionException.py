class StatusTransitionException(Exception):
    def __init__(self, exception_message: str = "Ticket status could not be transitioned to the wanted value,"
                                                "value is not part of the possible transitions, "
                                                "please check the corresponding Jira ticket."):
        self.exception_message = exception_message

        super().__init__(self.exception_message)
