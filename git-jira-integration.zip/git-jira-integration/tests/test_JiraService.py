from unittest import TestCase, mock
from unittest.mock import patch
from requests.exceptions import HTTPError

from IssueNotFoundException import IssueNotFoundException
from ServerResponseConversionException import ServerResponseConversionException
from StatusTransitionException import StatusTransitionException
from JiraService import JiraService


class TestJiraService(TestCase):
    @patch('JiraService.Jira')
    def setUp(self, mock_jira):
        self.mock_jira = mock_jira
        self.jira_service = JiraService(jira_url="https://test.jira.com", api_token="test_api_token")
        self.jira_service.jira = self.mock_jira


    def test_jira_issue_doesnt_exist(self):
        # Given
        self.mock_jira.issue_exists.return_value = False

        # When & Then
        with self.assertRaises(IssueNotFoundException) as context:
            self.jira_service._check_if_issue_exists("TEST-123")
        self.assertEqual("Could not find a jira ticket with an issue id of \"TEST-123\", please verify that the"
                         " ticket exists.", str(context.exception))

    def test_jira_issue_exists(self):
        # Given
        self.mock_jira.issue_exists.return_value = True

        # When & Then
        try:
            self.jira_service._check_if_issue_exists("TEST-123")
        except IssueNotFoundException:
            self.fail("IssueNotFoundException was raised unexpectedly.")

    def test_get_issue_enterprise_response(self):
        # Given
        self.mock_jira.issue.return_value = {
            'key': 'TEST-123',
            'url': 'https://test.jira.com/api/2/issue/TEST-123',
            'fields': {
                'assignee': {
                    'emailAddress': 'test@e-mail.com',
                    'name': 'test_user',
                    'random_assignee_field': 'test_value',
                    'random_assignee_field2': ['test_value1', 'test_value2'],
                    'random_assignee_field3': {'test_field': 'test_value'}}},
            'test_field': 'test_value',
            'test_field2': ['test_value1', 'test_value2'],
            'test_field3': {'test_field': 'test_value'},
            'test_field4': [{'test_field': 'test_value'}, {'test_field': 'test_value'}]}
        self.mock_jira.get_issue_status.return_value = 'In Progress'

        # When
        with mock.patch.object(self.jira_service, '_check_if_issue_exists', return_value=None):
            jira_ticket = self.jira_service.get_issue("TEST-123")

        # Then
        self.assertEqual(jira_ticket['issue_id'], 'TEST-123')
        self.assertEqual(jira_ticket['status'], 'In Progress')
        self.assertEqual(jira_ticket['assignee']['email'], 'test@e-mail.com')
        self.assertEqual(jira_ticket['assignee']['user_id'], 'test_user')

    def test_get_issue_cloud_response(self):
        # Given
        self.mock_jira.issue.return_value = {
            'key': 'TEST-123',
            'url': 'https://test.jira.com/api/2/issue/TEST-123',
            'fields': {
                'assignee': {
                    'emailAddress': 'test@e-mail.com',
                    'accountId': 'test_user_account_id',
                    'random_assignee_field': 'test_value',
                    'random_assignee_field2': ['test_value1', 'test_value2'],
                    'random_assignee_field3': {'test_field': 'test_value'}}},
            'test_field': 'test_value',
            'test_field2': ['test_value1', 'test_value2'],
            'test_field3': {'test_field': 'test_value'},
            'test_field4': [{'test_field': 'test_value'}, {'test_field': 'test_value'}]}
        self.mock_jira.get_issue_status.return_value = 'In Progress'

        # When
        with mock.patch.object(self.jira_service, '_check_if_issue_exists', return_value=None):
            jira_ticket = self.jira_service.get_issue("TEST-123")

        # Then
        self.assertEqual(jira_ticket['issue_id'], 'TEST-123')
        self.assertEqual(jira_ticket['status'], 'In Progress')
        self.assertEqual(jira_ticket['assignee']['email'], 'test@e-mail.com')
        self.assertEqual(jira_ticket['assignee']['user_id'], 'test_user_account_id')

    def test_get_issue_no_assignee(self):
        # Given
        self.mock_jira.issue.return_value = {
            'key': 'TEST-123',
            'url': 'https://test.jira.com/api/2/issue/TEST-123',
            'fields': {
                'assignee': None},
            'test_field': 'test_value',
            'test_field2': ['test_value1', 'test_value2'],
            'test_field3': {'test_field': 'test_value'},
            'test_field4': [{'test_field': 'test_value'}, {'test_field': 'test_value'}]}

        # When & Then
        with self.assertRaises(ServerResponseConversionException) as context:
            self.jira_service.get_issue("TEST-123")
            self.assertEqual("Failed to convert the server response into the necessary format, ticket has no assignee."
                         , str(context.exception))

    def test_get_issue_malformed_response(self):
        # Given
        self.mock_jira.issue.return_value = {
            # Missing key field
            'url': 'https://test.jira.com/api/2/issue/TEST-123',
            'fields': {}}  # Missing assignee field
        self.mock_jira.get_issue_status.return_value = 'In Progress'

        # When & Then
        with self.assertRaises(ServerResponseConversionException) as context:
            self.jira_service.get_issue("TEST-123")
            self.assertEqual("Failed to convert the server response into the necessary format,"
                             " server response seems to be malformed.", str(context.exception))

    def test_get_possible_transitions_correct__response(self):
        # Given
        self.mock_jira.get_issue_transitions.return_value = [
            {'id': '1', 'name': 'test_status_name', 'to': 'In Progress', 'random_field': 'test_value'},
            {'id': '2', 'name': 'test_status_name2', 'to': 'Done', 'random_field': 'test_value'}]

        # When
        with mock.patch.object(self.jira_service, '_check_if_issue_exists', return_value=None):
            possible_transitions = self.jira_service.get_possible_transitions("TEST-123")

        # Then
        self.assertEqual(possible_transitions, [{'id': '1', 'status': 'In Progress'},
                                                {'id': '2', 'status': 'Done'}])

    def test_get_possible_transitions_malformed_response(self):
        # Given
        self.mock_jira.get_issue_transitions.return_value = [
            {'id': '1', 'name': 'test_status_name', 'random_field': 'test_value'},
            {'id': '2', 'name': 'test_status_name2', 'random_field': 'test_value'}]

        # When & Then
        with self.assertRaises(ServerResponseConversionException) as context:
            self.jira_service.get_possible_transitions("TEST-123")
        self.assertEqual("Failed to extract possible issue status transitions from server response.",
                         str(context.exception))

    def test_update_issue_status_exception_from_server(self):
        # Given
        self.mock_jira.set_issue_status_by_transition_id.side_effect = HTTPError

        # When & Then
        with self.assertRaises(StatusTransitionException) as context:
            self.jira_service.update_issue_status("TEST-123", 1, "In Progress")
        self.assertEqual("Failed to transition issue \"TEST-123\" to status \"In Progress\".",
                         str(context.exception))
