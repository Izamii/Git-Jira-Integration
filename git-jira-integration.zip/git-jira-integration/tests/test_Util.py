from unittest import TestCase
from unittest.mock import patch

import Util
from DictionaryValidationException import DictionaryValidationException


class Test(TestCase):
    def test_successful_validate_dict(self):
        # Given
        dict_to_validate = {"key1": "value1", "key2": 2}
        validation_rules = {"key1": str, "key2": int}

        # When & Then
        try:
            Util.validate_dict(dict_to_validate, validation_rules)
        except (KeyError, TypeError) as e:
            self.fail(f"Function raised error unexpectedly: {e}")


    def test_missing_key_validate_dict(self):
        # Given
        dict_to_validate = {"key1": "value1"}
        validation_rules = {"key1": str, "key2": int}

        # When & Then
        with self.assertRaises(KeyError) as context:
            Util.validate_dict(dict_to_validate, validation_rules)
        self.assertEqual("'Dictionary does not contain the required key \"key2\".'", str(context.exception))

    def test_wrong_type_validate_dict(self):
        # Given
        dict_to_validate = {"key1": "value1", "key2": "2"}
        validation_rules = {"key1": str, "key2": int}

        # When & Then
        with self.assertRaises(TypeError) as context:
            Util.validate_dict(dict_to_validate, validation_rules)
        self.assertEqual("Dictionary field \"key2\" is of the wrong type!\nExpected type: \"<class 'int'>\","
                         " Provided type: \"<class 'str'>\".", str(context.exception))

    @patch('Util.read_json_file', return_value={"jira_url": "test", "api_token": "test"})
    def test_successful_load_jira_credentials(self, mock_read_json_file):
        # Given
        jira_cred_filepath = "test.json"

        # When
        result = Util.load_jira_credentials(jira_cred_filepath)

        # Then
        self.assertDictEqual(result, {"jira_url": "test", "api_token": "test"})

    @patch('Util.read_json_file', return_value={"jira_url": "test", "api_key": "test"})
    def test_malformed_jira_credentials(self, mock_read_json_file):
        # Given
        jira_cred_filepath = "test.json"

        # When & Then
        with self.assertRaises((KeyError, DictionaryValidationException)) as context:
            Util.load_jira_credentials(jira_cred_filepath)
        self.assertEqual("Failed to validate Jira credentials!\n'Dictionary does not contain the required key \"api_token\".'", str(context.exception))