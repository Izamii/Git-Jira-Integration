class DictionaryValidationException(Exception):
    def __init__(self, exception_message: str = "Failed to validate the given dictionary against the provided ruleset."):
        self.exception_message = exception_message

        super().__init__(self.exception_message)