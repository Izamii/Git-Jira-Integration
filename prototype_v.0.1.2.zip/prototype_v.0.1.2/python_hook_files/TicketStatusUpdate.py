import tkinter as tk
from tkinter import ttk


class TicketStatusUpdate:
    def __init__(self, root, status_transitions: list[dict[str, str or int]], ticket_id: str, current_status: str):
        self.root = root
        # to bring the root to the foreground on the desktop this link was consulted:
        # https://stackoverflow.com/questions/1892339/how-to-make-a-tkinter-window-jump-to-the-front
        self.root.lift()
        self.root.attributes('-topmost', True)
        self.root.after_idle(root.attributes, '-topmost', False)
        self.root.title("Ticket Status Update")
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        # Calculate the position for the window to be centered
        x_position = (self.root.winfo_screenwidth() - self.root.winfo_reqwidth()) // 2
        y_position = (self.root.winfo_screenheight() - self.root.winfo_reqheight()) // 2
        self.root.geometry(f"350x150+{x_position}+{y_position}")
        self.root.resizable(False, False)


        self.status_transitions = status_transitions
        self.ticket_id = ticket_id
        self.current_status = current_status
        self.new_status = None

        # Ticket ID
        self.ticket_id_frame = tk.Frame(self.root)
        self.ticket_id_frame.place(x=20, y=5)
        self.ticket_id_label = tk.Label(self.ticket_id_frame, text="TicketID:", font="Helvetica 8 bold")
        self.ticket_id_label.pack(side=tk.TOP)

        self.ticket_id_value = tk.Label(self.ticket_id_frame, text=self.ticket_id, font="Helvetica 8")
        self.ticket_id_value.pack(side=tk.BOTTOM)

        # New Status Options (Combobox)
        self.new_status_frame = tk.Frame(self.root)
        self.new_status_frame.place(x=110, y=25)
        self.new_status_label = tk.Label(self.new_status_frame, text="New Status:", font="Helvetica 8 bold")
        self.new_status_label.pack(side=tk.TOP, pady=10)

        # Extract the possible status options from the status transitions
        self.status_options = [transition['status'] for transition in self.status_transitions]
        # Add the current status to the list of options
        self.status_options.insert(0, self.current_status)
        self.new_status_combo = ttk.Combobox(self.new_status_frame, values=self.status_options)
        self.new_status_combo.state(['readonly'])
        self.new_status_combo['width'] = 15
        # Set the default value to the current status
        self.new_status_combo.current(0)
        self.new_status_combo.pack(side=tk.BOTTOM)

        # Current Status
        self.current_status_frame = tk.Frame(self.root)
        self.current_status_frame.place(x=240, y=5)
        self.current_status_label = tk.Label(self.current_status_frame, text="Current Status:", font="Helvetica 8 bold")
        self.current_status_label.pack(side=tk.TOP)

        self.current_status_value = tk.Label(self.current_status_frame, text=self.current_status, font="Helvetica 8")
        self.current_status_value.pack(side=tk.BOTTOM)

        # Buttons
        self.confirm_button = tk.Button(self.root, text="Confirm", command=self.confirm_action)
        self.confirm_button.place(x=20, y=105)

        self.cancel_button = tk.Button(self.root, text="Cancel", command=self.cancel_action)
        self.cancel_button.place(x=265, y=105)

    def confirm_action(self):
        # Check if the user selected the current status as the new status and set the transition id to None if so
        if self.new_status_combo.get() == self.current_status:
            self.new_status = {
                'id': None,
                'status': self.current_status
            }
        else:
            for transition in self.status_transitions:
                if transition['status'] == self.new_status_combo.get():
                    self.new_status = transition
        self.root.destroy()

    def cancel_action(self):
        self.root.destroy()


