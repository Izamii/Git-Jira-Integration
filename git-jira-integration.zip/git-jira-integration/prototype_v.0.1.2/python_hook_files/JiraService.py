from typing import Any

from atlassian import Jira
from requests.exceptions import HTTPError

from IssueNotFoundException import IssueNotFoundException
from MissingArgumentException import MissingArgumentException
from StatusTransitionException import StatusTransitionException
from ServerResponseConversionException import ServerResponseConversionException


class JiraService:
    def __init__(self, jira_url: str, **kwargs: object):
        if 'username' in kwargs:
            if 'api_token' in kwargs:
                self.jira = Jira(url=jira_url, username=kwargs['username'], password=kwargs['api_token'], cloud=True)
            elif 'password' in kwargs:
                self.jira = Jira(url=jira_url, username=kwargs['username'], password=kwargs['password'])
        elif 'api_token' in kwargs:
            self.jira = Jira(url=jira_url, token=kwargs['api_token'])
        else:
            raise MissingArgumentException(
                "Failed to initialize connection to Jira!\n"
                "Missing required arguments, please provide either a username and password or api_token.\n"
                "If you are using a cloud instance of Jira, please provide a username and api_token.")

    def _check_if_issue_exists(self, issue_id: str):
        if not self.jira.issue_exists(issue_id):
            raise IssueNotFoundException(f"Could not find a jira ticket with an issue id of \"{issue_id}\", please "
                                         f"verify that the ticket exists.")

    def get_issue(self, issue_id: str) -> dict:
        self._check_if_issue_exists(issue_id)
        server_response_issue = self.jira.issue(issue_id, "assignee")
        server_response_issue_status = self.jira.get_issue_status(issue_id)
        try:
            if server_response_issue['fields']['assignee'] is None:
                raise ServerResponseConversionException(f"Failed to convert the server response into the necessary"
                                                        f" format, ticket has no assignee.")
            # Convert the server response into a simpler format, with only the necessary fields
            jira_issue = {'issue_id': server_response_issue['key'], 'status': server_response_issue_status,
                          'assignee': {'email': server_response_issue['fields']['assignee']['emailAddress']}}
            if 'name' in server_response_issue['fields']['assignee']:
                jira_issue['assignee']['user_id'] = server_response_issue['fields']['assignee']['name']
            if 'accountId' in server_response_issue['fields']['assignee']:
                jira_issue['assignee']['user_id'] = server_response_issue['fields']['assignee']['accountId']
            return jira_issue
        except KeyError:
            raise ServerResponseConversionException(f"Failed to convert the server response into the necessary format,"
                                                    f" server response seems to be malformed.")

    def get_possible_transitions(self, issue_id) -> list[dict[str, Any]]:
        self._check_if_issue_exists(issue_id)
        possible_transitions = []
        server_response = self.jira.get_issue_transitions(issue_id)
        try:
            for transition in server_response:
                possible_transitions.append({
                    'id': transition['id'],
                    'status': transition['to']
                })

            return possible_transitions
        except KeyError:
            raise ServerResponseConversionException(f"Failed to extract possible issue status transitions from server "
                                                    f"response.")

    def update_issue_status(self, issue_id, new_status_id: int, status_name: str):
        self._check_if_issue_exists(issue_id)
        try:
            self.jira.set_issue_status_by_transition_id(issue_id, new_status_id)
        except HTTPError:
            raise StatusTransitionException(exception_message=f"Failed to transition issue \"{issue_id}\""
                                                              f" to status \"{status_name}\".")
