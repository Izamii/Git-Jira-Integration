from unittest import TestCase
from unittest.mock import patch

import PrePushHook
from DictionaryValidationException import DictionaryValidationException


class Test(TestCase):

    @patch('PrePushHook._validate_configurations')
    @patch('Util.read_json_file', return_value={'jira_cred_filepath': 'path',
                                                'pre-push': {'warning_on_failed_transition': True}})
    @patch('Util.load_jira_credentials', return_value={})
    def test_successful_load_configurations(self, mock_load_jira_credentials, mock_read_json_file, mock__validate_configurations):
        # Given

        # When & Then
        try:
            PrePushHook.load_configurations('path')
        except RuntimeError:
            self.fail("RuntimeError raised unexpectedly!")

    @patch('Util.read_json_file', return_value={})
    @patch('PrePushHook._validate_configurations', side_effect=PrePushHook.DictionaryValidationException('Failed to validate configurations!'))
    def test_invalid_load_configurations(self, mock__validate_configurations, mock_read_json_file):
        # Given

        # When & Then
        with self.assertRaises(RuntimeError) as context:
            PrePushHook.load_configurations('path')
        self.assertEqual("Error while loading the script configuration: Failed to validate configurations!", str(context.exception))

    @patch('Util.validate_dict')
    def test_successful_config_validation(self, mock_validate_dict):
        # Given
        config_file_content = {'jira_cred_filepath': 'path',
                               'pre-push': {'warning_on_failed_transition': True}}

        # When & Then
        try:
            PrePushHook._validate_configurations(config_file_content)
        except DictionaryValidationException:
            self.fail("DictionaryValidationException raised unexpectedly!")

    @patch('Util.validate_dict', side_effect=KeyError('Key \'pre-push\' not found!'))
    def test_invalid_config_validation(self, mock_validate_dict):
        # Given
        config_file_content = {'jira_cred_filepath': 'path'}

        # When & Then
        with self.assertRaises(DictionaryValidationException) as context:
            PrePushHook._validate_configurations(config_file_content)
        self.assertEqual("Failed to validate configurations!\n\"Key \'pre-push\' not found!\"", str(context.exception))

    @patch('PrePushHook.JiraService')
    @patch('PrePushHook.hook_config', {'warning_on_failed_transition': False})
    def test_successfully_transition_jira_issues(self, mock_JiraService):
        # Given
        example_transition_file_content = {'TEST-123': {'id': 1, 'status': 'status'}}
        mock_JiraService().update_issue_status.return_value = None

        # When & Then
        try:
            PrePushHook.transition_jira_issues(example_transition_file_content)
        except RuntimeError:
            self.fail("RuntimeError raised unexpectedly!")

    @patch('PrePushHook.JiraService')
    @patch('PrePushHook.hook_config', {'warning_on_failed_transition': True})
    @patch('PrePushHook.messagebox.askokcancel', return_value=False)
    def test_output_on_failed_transition(self, mock_askokcancel, mock_JiraService):
        # Given
        example_transition_file_content = {'TEST-123': {'id': 1, 'status': 'status'}}
        mock_JiraService().update_issue_status.side_effect = PrePushHook.StatusTransitionException('Failed to transition issue!')

        # When & Then
        with self.assertRaises(RuntimeError) as context:
            PrePushHook.transition_jira_issues(example_transition_file_content)
        self.assertEqual("Error while synchronizing issue status: Push aborted by user, due to failed issue transition.", str(context.exception))

    @patch('PrePushHook.JiraService')
    @patch('PrePushHook.hook_config', {'warning_on_failed_transition': True})
    @patch('PrePushHook.messagebox.askokcancel', return_value=True)
    def test_continue_on_failed_transition(self, mock_askokcancel, mock_JiraService):
        # Given
        example_transition_file_content = {'TEST-123': {'id': 1, 'status': 'status'}, 'TEST-124': {'id': 2, 'status': 'status'}}
        mock_JiraService().update_issue_status.side_effect = PrePushHook.StatusTransitionException('Failed to transition issue!')

        # When & Then
        try:
            PrePushHook.transition_jira_issues(example_transition_file_content)
        except RuntimeError:
            self.fail("RuntimeError raised unexpectedly!")

    @patch('Util.read_json_file', return_value={"TEST-123": {"id": 1, "status": "status"}})
    @patch('PrePushHook._validate_transition_file')
    def test_successfully_load_transition_file(self, mock__validate_transition_file, mock_read_json_file):
        # Given
        expected_output = {"TEST-123": {"id": 1, "status": "status"}}
        # When
        result = PrePushHook.load_transition_file('path')

        # Then
        self.assertDictEqual(expected_output, result)

    @patch('Util.read_json_file', return_value={})
    @patch('PrePushHook._validate_transition_file', side_effect=PrePushHook.DictionaryValidationException('Failed to validate transition file!'))
    def test_invalid_load_transition_file(self, mock__validate_transition_file, mock_read_json_file):
        # Given

        # When & Then
        with self.assertRaises(RuntimeError) as context:
            PrePushHook.load_transition_file('path')
        self.assertEqual("Error while loading the transition file: Failed to validate transition file!", str(context.exception))

    def test_successfully_validate_transition_file(self):
        # Given
        transition_file_content = {"TEST-123": {"id": 1, "status": "status"}}

        # When & Then
        try:
            PrePushHook._validate_transition_file(transition_file_content)
        except PrePushHook.DictionaryValidationException:
            self.fail("DictionaryValidationException raised unexpectedly!")

    def test_invalid_type_validate_transition_file(self):
        # Given
        transition_file_content = {"TEST-123": "Test"}

        # When & Then
        with self.assertRaises(DictionaryValidationException) as context:
            PrePushHook._validate_transition_file(transition_file_content)
        self.assertEqual("Failed to validate transition file!\nDictionary field \"TEST-123\""
                         " is of the wrong type!\nExpected type: \"<class 'dict'>\","
                         " Provided type: \"<class 'str'>\".", str(context.exception))

    @patch('Util.write_json_file')
    def test_successful_empty_transition_file(self, mock_write_json_file):
        # Given

        # When & Then
        try:
            PrePushHook.empty_transition_file('path')
        except RuntimeError:
            self.fail("RuntimeError raised unexpectedly!")

    @patch('Util.write_json_file', side_effect=IOError('Failed to empty transition file!'))
    def test_invalid_empty_transition_file(self, mock_write_json_file):
        # Given

        # When & Then
        with self.assertRaises(RuntimeError) as context:
            PrePushHook.empty_transition_file('path')
        self.assertEqual("Error while emptying the transition file: Failed to empty transition file!", str(context.exception))
