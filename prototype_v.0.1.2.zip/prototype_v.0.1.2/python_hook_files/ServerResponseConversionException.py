class ServerResponseConversionException(Exception):
    def __init__(self, exception_message: str = "Failed to convert the response from the jira server."):
        self.exception_message = exception_message

        super().__init__(self.exception_message)
