class IssueNotFoundException(Exception):
    def __init__(self, exception_message: str = "Jira Issue Ticket could not be found."):
        self.exception_message = exception_message

        super().__init__(self.exception_message)
