class MissingArgumentException(Exception):
    def __init__(self, exception_message: str = "Missing required arguments."):
        self.exception_message = exception_message

        super().__init__(self.exception_message)