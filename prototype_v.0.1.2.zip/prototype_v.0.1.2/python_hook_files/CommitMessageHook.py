import os
import sys
import tkinter as tk
from tkinter import messagebox

import Util as Util
from CommitValidationException import CommitValidationException
from DictionaryValidationException import DictionaryValidationException
from IssueNotFoundException import IssueNotFoundException
from MissingArgumentException import MissingArgumentException
from ServerResponseConversionException import ServerResponseConversionException
from TicketStatusUpdate import TicketStatusUpdate
from JiraService import JiraService

jira_credentials = {}
hook_config = {}
current_directory = os.getcwd().replace('\\', '/') + "/"


def extract_ticket_id(commit_message: list) -> str | None:
    ticket_id = None
    for commit_message_line in commit_message:
        if commit_message_line.startswith("TicketID:"):
            ticket_id = commit_message_line.split(":", 1)[1].strip()
    return ticket_id


def process_commit_message(commit_message_path: str, user_email: str) -> dict:
    try:
        commit_message_content = Util.read_simple_file(commit_message_path)
        # Requirement #1: The commit message must contain a valid ticket ID
        ticket_id = extract_ticket_id(commit_message_content)
        if ticket_id is None:
            raise CommitValidationException("A valid ticketID was not present in commit message.\nPlease use the following format:"
                             "\"TicketID: XXXXXX\" to delimit your ticket ID! (X's are to be replaced by the actual ID)")

        # Requirement #3: Check commit validity
        return check_commit_validity(ticket_id, user_email)
    except (IOError, CommitValidationException) as e:
        raise RuntimeError(f"Error while processing the commit: " + str(e))


def check_commit_validity(ticket_id: str, user_email: str) -> dict[str, object]:
    try:
        # Requirement #2: Connect to Jira
        jira = JiraService(**jira_credentials)
        # Requirement #3.1: The ticket must exist
        issue = jira.get_issue(ticket_id)
        transitions = jira.get_possible_transitions(ticket_id)
        # Requirement #3.2: The ticket must be in a valid commitable status
        if issue['status'] not in hook_config['commit-msg']['valid_commit_status']:
            raise CommitValidationException(f"The ticket \"{ticket_id}\" is in a not commitable status ({issue['status']}).")
        # Requirement #6.2: Only validate assignee if the team wants to validate it
        if hook_config['commit-msg']['validate_assignee']:
            # Requirement #3.3: The ticket must be assigned to the user
            if issue['assignee']['email'] != user_email:
                # Requirement #6.3 Only ask for confirmation if the team wants warnings on invalid assignees
                if hook_config['commit-msg']['warning_on_invalid_assignee']:
                    if not messagebox.askokcancel("Warning", f"The ticket \"{ticket_id}\" is not assigned to you.\n"
                                                             f"Would you like to continue?"):
                        raise CommitValidationException(f"Commit aborted by user, ticket \"{ticket_id}\" is not assigned to user.")
                else:
                    raise CommitValidationException(f"Ticket \"{ticket_id}\" is not assigned to you.")
        return {"issue": issue, "transitions": transitions}
    except (MissingArgumentException, IssueNotFoundException, ServerResponseConversionException, CommitValidationException) as e:
        raise CommitValidationException(str(e))


def load_metadata_file(filepath: str) -> dict[str, object]:
    if not os.path.isfile(filepath):
        if messagebox.askokcancel("Warning", f"Could not find the meta info file at: \"{filepath}\".\n"
                                             f"Would you like to create a new file?"):
            return {}
        raise IOError(f"Could not find metadata file at: \"{filepath}\".")
    metadata = Util.read_json_file(filepath)
    return metadata


def update_metadata_file(filepath: str, commit_files_filepath: str, ticket_id: str, ticket_status: str, assignee: str,
                         jira_base_url: str):
    try:
        metadata = load_metadata_file(filepath)
        commit_files = Util.read_simple_file(commit_files_filepath)

        # Update metadata for each file in the commit
        for commit_file in commit_files:
            # Skip the .gitignore file if it is in the commit since it is not a file that should be tracked
            if commit_file == ".gitignore":
                continue
            metadata.setdefault(commit_file, {})
            # Requirement #5: Update metadata file with the new ticket information
            metadata[commit_file]["jira_properties"] = {
                "ticket_id": ticket_id,
                "ticket_status": ticket_status,
                "assignee": assignee,
                "ticket_url": jira_base_url + "browse/" + ticket_id
            }
            # Requirement #5.1: Differentiate between km and jira properties
            # Set default value for km properties if they don't exist
            metadata[commit_file].setdefault("km_properties", {})

        # Update ticket status & assignee for all elements in the metadata file that have the same ticket id but weren't part of the commit
        # This is experimental and might slow down the hook if the metadata file gets too big
        for element in metadata:
            # Prior validation would remove the need for a try catch block
            try:
                if metadata[element]["jira_properties"]["ticket_id"] == ticket_id and metadata[element]["jira_properties"]["ticket_status"] != ticket_status:
                    metadata[element]["jira_properties"]["ticket_status"] = ticket_status
                    metadata[element]["jira_properties"]["assignee"] = assignee
            except KeyError:
                raise KeyError(f"Failed to update \"{element}\" in the metadata file, the element does not contain the necessary jira properties.")
        Util.write_json_file(filepath, metadata)
    except (IOError, KeyError) as e:
        raise RuntimeError("Error while updating the metadata file: " + str(e))


def load_configurations(config_filepath: str):
    try:
        # Load the configuration file
        config_json = Util.read_json_file(config_filepath)
        # Validate the configuration file
        _validate_configurations(config_json)

        global jira_credentials
        # Load & validate jira credentials from filepath in config file
        jira_credentials = Util.load_jira_credentials(current_directory + config_json['jira_cred_filepath'])

        global hook_config
        hook_config = config_json
    except (IOError, DictionaryValidationException) as e:
        raise RuntimeError("Error while loading the script configuration: " + str(e))


def _validate_configurations(config_json: dict[str, object]):
    # Validation rules for the configuration file based on the json schema from thesis document
    base_validation_rules = {
        "jira_cred_filepath": str,
        "metadata_filepath": str,
        "commit-msg": dict
    }
    commit_msg_validation_rules = {
        "validate_assignee": bool,
        "warning_on_invalid_assignee": bool,
        "valid_commit_status": list
    }
    try:
        Util.validate_dict(config_json, base_validation_rules)
        Util.validate_dict(config_json['commit-msg'], commit_msg_validation_rules)
    except (KeyError, TypeError) as e:
        raise DictionaryValidationException(f"Failed to validate the configuration file!\n{str(e)}")


def create_system_commit_file(jira_ticket_id: str):
    system_commit_filepath = current_directory + ".git/.system_commit"
    try:
        with open(system_commit_filepath, 'w') as file:
            file.write(jira_ticket_id)
        return True
    except FileNotFoundError:
        raise RuntimeError(f"Error while creating the system commit flag: Could not write to file at \"{system_commit_filepath}\", file not found.")
    except PermissionError:
        raise RuntimeError(f"Error while creating the system commit flag: Could not write to file at \"{system_commit_filepath}\", permission denied.")

def append_push_transition_to_file(jira_ticket_id: str, status_transition: dict[str, object]):
    transition_file_filepath = current_directory + ".git/.status_transitions"
    try:
        transition_file = Util.read_json_file(transition_file_filepath)
    except IOError:
        transition_file = {}
    try:
        if status_transition['id'] is not None:
            transition_file[jira_ticket_id] = status_transition
        else:
            # in case a commit was reverted and a transition shouldn't happen in this commit
            transition_file.pop(jira_ticket_id, None)
        Util.write_json_file(transition_file_filepath, transition_file)
    except IOError as e:
        raise RuntimeError(f"Error while updating the status transition file: " + str(e))

def main() -> int:
    try:
        # Check if the .system_commit file exists in the .git folder
        if Util.check_for_system_commit(current_directory):
            # If file is empty, system commit is in progress -> Do not process commit
            if Util.check_system_commit_file_empty(current_directory):
                return 0
            else:
                raise RuntimeError(f"System commit file is not empty, post commit hook failed.\nPlease check your commit"
                                 f" history, and if necessary, revert the last commit.\nFurthermore remove the following file:"
                                 f" \"{current_directory}.git/.system_commit\".")

        if len(sys.argv) != 5:
            raise MissingArgumentException("Script was invoked with an invalid amount of arguments!")
        commit_message_path = sys.argv[1]
        config_filepath = sys.argv[2]
        user_email = sys.argv[3]
        commit_files_filepath = sys.argv[4]

        # Requirement #6
        load_configurations(current_directory + config_filepath)
        # Requirement #1 & #3: Process the commit message & validate it based on jira server information
        jira_ticket = process_commit_message(current_directory + commit_message_path, user_email)

        # Requirement #4: Open a GUI window to ask the user for the new status
        root = tk.Tk()
        ticket_update_window = TicketStatusUpdate(root, jira_ticket['transitions'], jira_ticket['issue']['issue_id'],
                                                  jira_ticket['issue']['status'])
        root.mainloop()
        if ticket_update_window.new_status is None:
            raise RuntimeError("Commit cancelled, user aborted the status update process.")

        # Requirement #5: update & save the metadata file
        update_metadata_file(current_directory + hook_config['metadata_filepath'], current_directory + commit_files_filepath,
                             jira_ticket['issue']['issue_id'], ticket_update_window.new_status['status'],
                             jira_ticket['issue']['assignee']['user_id'], jira_credentials['jira_url'])
        create_system_commit_file(jira_ticket['issue']['issue_id'])

        # Requirement #4.1: Append the new status transition to the push transition file so the push hook can sync the status
        append_push_transition_to_file(jira_ticket['issue']['issue_id'], ticket_update_window.new_status)
        return 0
    except (RuntimeError, MissingArgumentException) as e:
        sys.stderr.write(str(e))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
