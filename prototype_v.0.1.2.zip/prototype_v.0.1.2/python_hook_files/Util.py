import json
import os

from DictionaryValidationException import DictionaryValidationException


def read_json_file(filepath: str) -> dict[str, object]:
    try:
        with open(filepath, 'r') as file:
            data = json.load(file)
            return data
    except FileNotFoundError:
        raise IOError(f"Could not find file at \"{filepath}\".")
    except PermissionError:
        raise IOError(f"Could not read file at \"{filepath}\".")
    except json.JSONDecodeError:
        raise IOError(f"File \"{filepath}\" is not a valid json file.")


def write_json_file(filepath: str, data: dict[str, object]):
    try:
        with open(filepath, 'w') as json_file:
            json.dump(data, json_file, indent=4)
    except FileNotFoundError:
        raise IOError(f"Could not open file at \"{filepath}\", file not found.")
    except PermissionError:
        raise IOError(f"Could not write to file at \"{filepath}\", permission denied.")


def read_simple_file(filepath: str) -> list:
    content_list = []
    try:
        with open(filepath, "r") as file:
            raw_content = file.readlines()
            for line in raw_content:
                content_list.append(line.replace("\n", "").strip())
        return content_list
    except FileNotFoundError:
        raise IOError(f"Could not find file at \"{filepath}\".")
    except PermissionError:
        raise IOError(f"Could not read file at \"{filepath}\".")


def check_for_system_commit(current_work_directory:str) -> bool:
    if os.path.isfile(current_work_directory + ".git/.system_commit"):
        return True
    return False

def check_system_commit_file_empty(current_work_directory: str) -> bool:
    system_commit_filepath = current_work_directory + ".git/.system_commit"
    return os.path.getsize(system_commit_filepath) == 0

def validate_dict(dict_to_validate: dict[str, object], validation_rules: dict[str, type]):
    for key, value in validation_rules.items():
        if key not in dict_to_validate:
            raise KeyError(f"Dictionary does not contain the required key \"{key}\".")
        if not isinstance(dict_to_validate[key], value):
            raise TypeError(f"Dictionary field \"{key}\" is of the wrong type!\n"
                            f"Expected type: \"{value}\", Provided type: \"{type(dict_to_validate[key])}\".")


def load_jira_credentials(jira_cred_filepath: str) -> dict[str, object]:
    credential_validation_rules = {
        "jira_url": str,
        "api_token": str
    }
    try:
        jira_credentials = read_json_file(jira_cred_filepath)
        validate_dict(jira_credentials, credential_validation_rules)
        return jira_credentials
    except IOError as e:
        raise IOError(str(e))
    except (KeyError, TypeError) as e:
        raise DictionaryValidationException(f"Failed to validate Jira credentials!\n{str(e)}")
