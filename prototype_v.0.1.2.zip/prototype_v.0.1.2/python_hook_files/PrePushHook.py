import os
import sys
from tkinter import messagebox

import Util
from DictionaryValidationException import DictionaryValidationException
from IssueNotFoundException import IssueNotFoundException
from JiraService import JiraService
from MissingArgumentException import MissingArgumentException
from StatusTransitionException import StatusTransitionException

current_directory = os.getcwd().replace('\\', '/') + "/"
jira_credentials = {}
hook_config = {}


def load_configurations(config_filepath: str):
    try:
        config_json = Util.read_json_file(config_filepath)
        _validate_configurations(config_json)

        global jira_credentials
        jira_credentials = Util.load_jira_credentials(current_directory + config_json['jira_cred_filepath'])

        global hook_config
        hook_config = config_json["pre-push"]
    except (IOError, DictionaryValidationException) as e:
        raise RuntimeError("Error while loading the script configuration: " + str(e))


def _validate_configurations(config_file_content: dict[str, object]):
    base_validation_rules = {
        "jira_cred_filepath": str,
        "pre-push": dict
    }
    pre_push_validation_rules = {
        "warning_on_failed_transition": bool
    }
    try:
        Util.validate_dict(config_file_content, base_validation_rules)
        Util.validate_dict(config_file_content["pre-push"], pre_push_validation_rules)
    except (KeyError, TypeError) as e:
        raise DictionaryValidationException(f"Failed to validate configurations!\n{e}")


def transition_jira_issues(transition_file_content: dict[str, dict]):
    try:
        # Requirement #2: Connect to Jira
        jira = JiraService(**jira_credentials)
        for key in transition_file_content:
            try:
                jira.update_issue_status(key, transition_file_content[key]["id"], transition_file_content[key]['status'])
            except StatusTransitionException as e:
                if hook_config['warning_on_failed_transition']:
                    if not messagebox.askokcancel("Warning", f"Failed to transition issue \"{key}\" to status "
                                                             f"\"{transition_file_content[key]['status']}\", do you want "
                                                             f"to continue?"):
                        raise StatusTransitionException(f"Push aborted by user, due to failed issue transition.")
                    continue
                else:
                    raise StatusTransitionException(str(e))
    except (MissingArgumentException, IssueNotFoundException, StatusTransitionException) as e:
        raise RuntimeError(f"Error while synchronizing issue status: {str(e)}")


def empty_transition_file(transition_filepath: str):
    try:
        Util.write_json_file(transition_filepath, {})
    except IOError as e:
        raise RuntimeError("Error while emptying the transition file: " + str(e))


def load_transition_file(transition_filepath: str) -> dict[str, dict]:
    try:
        transition_file_content = Util.read_json_file(transition_filepath)
        _validate_transition_file(transition_file_content)
        return transition_file_content
    except (IOError, DictionaryValidationException) as e:
        raise RuntimeError("Error while loading the transition file: " + str(e))


def _validate_transition_file(transition_file_content: dict[str, object]):
    transition_file_rules = {
        "id": int,
        "status": str
    }
    for key in transition_file_content:
        try:
            if not isinstance(transition_file_content[key], dict):
                raise TypeError(f"Dictionary field \"{key}\" is of the wrong type!\n"
                                f"Expected type: \"{dict}\", Provided type: \"{type(transition_file_content[key])}\".")
            Util.validate_dict(transition_file_content[key], transition_file_rules)
        except (KeyError, TypeError) as e:
            raise DictionaryValidationException(f"Failed to validate transition file!\n{str(e)}")


def main() -> int:
    try:
        if len(sys.argv) != 3:
            raise RuntimeError("Script was invoked with an invalid amount of arguments!")
        config_filepath = current_directory + sys.argv[1]
        transition_filepath = current_directory + sys.argv[2]

        load_configurations(config_filepath)
        # Read transition file and validate it
        transition_file_content = load_transition_file(transition_filepath)

        # Requirement #4.1
        transition_jira_issues(transition_file_content)
        empty_transition_file(transition_filepath)
        return 0
    except RuntimeError as e:
        sys.stderr.write(str(e))
        return 1

if __name__ == '__main__':
    raise SystemExit(main())